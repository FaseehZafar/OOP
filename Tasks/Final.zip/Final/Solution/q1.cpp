#include <iostream>
using namespace std;

// Recursive function to calculate the length of a string
int getStringLength(char *str) {
    if (*str == '\0') {
        return 0;
    }
    // Recursive case: 1 + length of the rest of the string
    return 1 + getStringLength(str + 1);
}


int main() {
    // Test cases
    string test1 = "123456";
    string test2 = "moyeMoye";
    string test3 = "";  // Empty string
    string test4 = "OOP Lab";
    string test5 = "Recursion is fun!";

    char *ptr1 = &test1[0];
    char *ptr2 = &test2[0];
    char *ptr3 = &test3[0];
    char *ptr4 = &test4[0];
    char *ptr5 = &test5[0];

    // Printing the results
    cout << " String = " << test1 << ", Expected = 6, Your output = " << getStringLength(ptr1) << endl;
    cout << " String = " << test2 << ", Expected = 8, Your output = " << getStringLength(ptr2) << endl;
    cout << " String = " << test3 << ", Expected = 0, Your output = " << getStringLength(ptr3) << endl;
    cout << " String = " << test4 << ", Expected = 7, Your output = " << getStringLength(ptr4) << endl;
    cout << " String = " << test5 << ", Expected = 17, Your output = " << getStringLength(ptr5) << endl;
    return 0;
}