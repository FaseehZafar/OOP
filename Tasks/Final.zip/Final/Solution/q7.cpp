#include <iostream>
#include <string>

using namespace std;

class Customer {
private:
    string name;
    int age;

public:
    // Constructor
    Customer(const string& name, int age) : name(name), age(age) {}
    Customer() : name(""), age(0) {}

    // Getter for name
    string getName() const {
        return name;
    }

    // Setter for name
    void setName(const string& newName) {
        name = newName;
    }

    // Getter for age
    int getAge() const {
        return age;
    }

    // Setter for age
    void setAge(int newAge) {
        if (newAge >= 0) { // Optional validation to ensure age is non-negative
            age = newAge;
        } else {
            cout << "Invalid age. Age must be non-negative." << endl;
        }
    }
};

struct Product {
    string productName;
    double price;

    // Parametrized Constructor
    Product(const string& productName, double price) : productName(productName), price(price) {}

    // Default Constructor
    Product() : productName(""), price(0.0) {}
};

class Order {
private:
    Customer customer;
    struct OrderItem {
        Product product;
        int quantity;

        OrderItem() {}
        OrderItem(const Product product, int quantity) : product(product), quantity(quantity) {}
    };
    OrderItem* items;
    int numberOfItems;
    int itemCount;

public:
    // Constructor
    Order(const Customer& customer, int numberOfItems) : customer(customer), numberOfItems(numberOfItems) {
        itemCount = 0;
        items = new OrderItem[numberOfItems];
    }

    // Destructor to release dynamically allocated memory
    ~Order() {
        delete[] items;
    }

    // Function to add an item to the order
    void addItem(const string& productName, double price, int quantity) {
        // Allocate memory for new item
        Product product(productName,price);
        OrderItem newItem(product,quantity);
        items[itemCount++] = newItem;
    }

    // Function to display the order
    void displayOrder() const {
        cout << "Customer: " << customer.getName() << endl;
        cout << "Items:" << endl;
        for (int i = 0; i < itemCount; ++i) {
            cout << "Product: " << items[i].product.productName << ", Price: $" << items[i].product.price
                 << ", Quantity: " << items[i].quantity << endl;
        }
    }
};

int main() {
    // Create a Customer
    Customer customer("John Doe", 30);

    // Create an Order
    Order order(customer,2);

    // Add items to the order
    order.addItem("Laptop", 999.99, 2);
    order.addItem("Phone", 699.99, 1);

    // Display the order
    order.displayOrder();

    return 0;
}