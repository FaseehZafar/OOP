#include<iostream>
using namespace std;

void printCharacter(char character, int count, int iterator = 1) {
    if (iterator > count) {
        return;
    }
    cout << character;
    printCharacter(character,count,iterator+1);
}


void pattern(int n, int iterator = 0) {

    if (iterator >= n) {
        return;
    }

    printCharacter(' ' , n-iterator-1);
    cout << "*";
    printCharacter(' ',iterator*2);
    cout << "*" << endl;

    pattern(n,iterator+1);   // recursive call 

    printCharacter(' ' , n-iterator-1);
    cout << "o";
    printCharacter(' ',iterator*2);
    cout << "o" << endl;
    
}

int main(){
    cout << endl << "........Printing for 3.......\n" << endl;
    pattern(3);
    cout << endl << "........Printing for 5.........\n" << endl;
    pattern(5);
    cout << endl << "........Printing for 7.........\n" << endl;
    pattern(7);
}


// #include<iostream>
// using namespace std;

// void printCharacter(char character, int count, int iterator = 1) {
//     if (iterator > count) {
//         cout << endl;
//         return;
//     }
//     cout << character;
//     printCharacter(character,count,iterator+1);
// }


// void box(int n, int iterator = 1) {

//     if (iterator > n) {
//         return;
//     }

//     printCharacter('o',n);
//     box(n,iterator+1);   // recursive call 
//     printCharacter('*',n);
// }

// void pattern(int n, int iterator = 1) {

//     if (iterator > n) {
//         return;
//     }

//     box(iterator);
//     pattern(n,iterator+1);   // recursive call 
//     box(iterator);
// }

// int main(){
//     cout << endl << "........Printing for 5.......\n" << endl;
//     pattern(5);
//     // cout << endl << "........Printing for 7.........\n" << endl;
//     // pattern(6);
//     // cout << endl << "........Printing for 9.........\n" << endl;
//     // pattern(8);
// }