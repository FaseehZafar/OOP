#include <iostream>
using namespace std;

void printLine(int dimension, int stericCount,char character,int i=1) {

    if (i>dimension){
        return;
    }

    if (i <= stericCount || i > dimension - stericCount) {
        cout << character;
    }
    else {
        cout << " ";
    }
    printLine(dimension,stericCount,character,i+1);
}

void pattern1(const int dimension, int i=1) {

    if (i>(dimension/2)+1) {                      // .......line 2.........//
        return;                     // .......line 3.........//
    }
    
    printLine(dimension,i,'*');       // .......line 4.........//
    printLine(dimension,i,'o'); 
    cout << endl;
    pattern1(dimension,i+1);     // .......line 5.........//
    printLine(dimension,i,'o');     // .......line 6.........//
    printLine(dimension,i,'*');
    cout << endl;

}

int main(){
    cout << "Enter an odd integer: ";
    int number; cin >> number;
    cout << endl;
    pattern1(number); 
}
