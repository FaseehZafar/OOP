#include <iostream>
#include <string>
using namespace std;

class Student {
protected:
    string name;
    int age;

public:
    // Constructor
    Student(const string& name, int age) : name(name), age(age) {}
    Student(){}

    // Virtual Destructor
    virtual ~Student() {}

    // Virtual function to get student details
    virtual void getDetails()  {
        cout << "Name: " << name << ", Age: " << age;
    }

    // Pure virtual function to get student type
    virtual string getStudentType() {
        return "abc";
    }
};

class BachelorStudent : public Student {
private:
    string major;

public:
    // Constructor
    BachelorStudent(const string& name, int age, const string& major)
        : Student(name, age), major(major) {}

    // Override getDetails function
    void getDetails()  {
        Student::getDetails();
        cout << ", Major: " << major << endl;
    }

    // Override getStudentType function
    string getStudentType()  {
        return "Bachelor";
    }
};

class MasterStudent : public Student {
private:
    string researchTopic;
    int researchYears;

public:
    // Constructor
    MasterStudent(const string& name, int age, const string& researchTopic, int researchYears)
        : Student(name, age), researchTopic(researchTopic),researchYears(researchYears) {}

    // Override getDetails function
    void getDetails() {
        Student::getDetails();
        cout << ", Research Topic: " << researchTopic << ", Research Years = " << researchYears<< endl;
    }

    // Override getStudentType function
    string getStudentType() {
        return "Master";
    }
};

class Academy {
private:
    Student* students[4];
    int number_of_students;
    int studentCount;

public:
    // Parametrized Constructor
    Academy(int number_of_students) {
        studentCount = 0;
        this->number_of_students = number_of_students;
    }

    // Destructor
    ~Academy() {
        //delete[] students;
    }

    // Function to add a Bachelor student
    void addStudent(const string& name, int age, const string& major) {
        students[studentCount++] = new BachelorStudent(name, age, major);
    }

    // Function to add a Master student
    void addStudent(const string& name, int age, const string& researchTopic, int researchYears) {
        students[studentCount++] = new MasterStudent(name, age, researchTopic,researchYears);
    }

    // Function to display all students
    void displayStudents() const {
        for (int i = 0; i < number_of_students; ++i) {
            cout << "Student Type: " << students[i]->getStudentType() << endl;
            students[i]->getDetails();
        }
    }
};

int main() {
    Academy academy(4);

    // Add Bachelor students
    academy.addStudent("Alice", 20, "Computer Science");
    academy.addStudent("Charlie", 21, "Mechanical Engineering");

    // Add Master students
    academy.addStudent("Bob", 25, "Artificial Intelligence", 2);
    academy.addStudent("David", 26, "Data Science", 1);

    // Display all students
    academy.displayStudents();

    return 0;
}